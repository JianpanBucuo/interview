package com.smartrm.smartrmtrade.trade.domain;

/**
 * @author: yoda
 * @description:
 */
public class DeviceFailure {

}
