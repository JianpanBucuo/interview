package com.smartrm.smartrmuser.user.adapter.wxminipro.vo;

/**
 * @author: yoda
 * @description:
 */
public class SignInResultVo {

  int result;

  public int getResult() {
    return result;
  }

  public void setResult(int result) {
    this.result = result;
  }
}
