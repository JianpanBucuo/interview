package com.smartrm.infracore.security;

/**
 * @author: yoda
 * @description:
 */
public enum Authority {
  OpenCabinet;
}
