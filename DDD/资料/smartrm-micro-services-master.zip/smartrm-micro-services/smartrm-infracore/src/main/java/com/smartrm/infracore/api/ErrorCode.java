package com.smartrm.infracore.api;

public interface ErrorCode {

  int getCode();

  String getMsg();
}
